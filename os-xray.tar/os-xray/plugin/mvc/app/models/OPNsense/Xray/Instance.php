<?php

namespace OPNsense\Xray;

use OPNsense\Base\BaseModel;

class Instance extends BaseModel
{
}
