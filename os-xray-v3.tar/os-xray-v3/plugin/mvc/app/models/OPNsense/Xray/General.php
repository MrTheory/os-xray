<?php

namespace OPNsense\Xray;

use OPNsense\Base\BaseModel;

class General extends BaseModel
{
}
